package br.edu.qi.projakbdescolan.model.dto

class Usuario {
    var id : Int = 0
    var nome : String? = null
    var cpf : Long = 0
    var telefone : String? = null
    var usuario : String? = null
    var senha : String? = null


    override fun toString(): String {
        return """
             :::::::::::::::::::::::::::::::::::::::::::::::::
               ID: $id 
               Nome: $nome
               Cpf: $cpf
               Telefone: $telefone
               Usuário: $usuario
               Senha: $senha
             :::::::::::::::::::::::::::::::::::::::::::::::::   
            """.trimIndent()
    }


}