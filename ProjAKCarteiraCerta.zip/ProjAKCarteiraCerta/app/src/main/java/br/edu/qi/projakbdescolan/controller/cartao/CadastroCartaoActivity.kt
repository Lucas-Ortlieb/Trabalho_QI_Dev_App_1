package br.edu.qi.projakbdescolan.controller.cartao

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import br.edu.qi.projakbdescolan.controller.LoginActivity
import br.edu.qi.projakbdescolan.controller.MainActivity
import br.edu.qi.projakbdescolan.controller.usuario.ListarActivity
import br.edu.qi.projakbdescolan.databinding.ActivityCadastroBinding
import br.edu.qi.projakbdescolan.databinding.ActivityCadastroCartaoBinding
import br.edu.qi.projakbdescolan.model.dao.CartaoDAO
import br.edu.qi.projakbdescolan.model.dao.UsuarioDAO
import br.edu.qi.projakbdescolan.model.dto.Cartao
import br.edu.qi.projakbdescolan.model.dto.Usuario

class CadastroCartaoActivity :AppCompatActivity() {
    private lateinit var binding: ActivityCadastroCartaoBinding
    private lateinit var objCartao: Cartao
    private lateinit var objCartaoDAO: CartaoDAO

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCadastroCartaoBinding.inflate(layoutInflater)
        setContentView(binding.root)


        binding.btnCadastrar.setOnClickListener {
            objCartao = Cartao()

            objCartao.nomeBanco = binding.edtNomeBanco.text.toString()
            objCartao.diaVencimento = binding.edtDiaVencimento.text.toString().toInt()
            objCartao.limite = binding.edtLimite.text.toString().toFloat()

            objCartaoDAO = CartaoDAO(this@CadastroCartaoActivity)

            objCartaoDAO.cadastrarCartao(objCartao)
            startActivity(Intent(this@CadastroCartaoActivity, ListarCartaoActivity::class.java))
        }

        binding.txtCancelarCadastro.setOnClickListener {
            startActivity(Intent(this@CadastroCartaoActivity, ListarCartaoActivity::class.java))
        }

    }
}