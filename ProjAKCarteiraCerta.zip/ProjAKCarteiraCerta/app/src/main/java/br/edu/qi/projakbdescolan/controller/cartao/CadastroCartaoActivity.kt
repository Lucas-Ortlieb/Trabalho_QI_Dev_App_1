package br.edu.qi.projakbdescolan.controller.cartao

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import br.edu.qi.projakbdescolan.controller.usuario.ListarActivity
import br.edu.qi.projakbdescolan.databinding.ActivityCadastroCartaoBinding
import br.edu.qi.projakbdescolan.model.dao.CartaoDAO
import br.edu.qi.projakbdescolan.model.dto.Cartao

class CadastroCartaoActivity :AppCompatActivity() {
    private lateinit var binding: ActivityCadastroCartaoBinding
    private var objCartao: Cartao? = null
    private lateinit var objCartaoDAO: CartaoDAO

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCadastroCartaoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val i = intent

        if (i.hasExtra("cartao_alterar")) {
            objCartao = i.getSerializableExtra("cartao_alterar") as Cartao
            binding.edtNomeBanco.setText(objCartao!!.nomeBanco)
            binding.edtDiaVencimento.setText(objCartao!!.diaVencimento.toString())
            binding.edtLimite.setText(objCartao!!.limite.toString())

            binding.btnCadastrar.text = "Alterar"
            binding.txtCancelarCadastro.setText("Altere os dados")

        } else if (i.hasExtra("novo_cartao")) {
            binding.txtCancelarCadastro.visibility = View.INVISIBLE
        }
        binding.txtCancelarCadastro.setOnClickListener {
            startActivity(Intent(this@CadastroCartaoActivity, ListarCartaoActivity::class.java))
        }


        binding.btnCadastrar.setOnClickListener {
            if(objCartao == null) {
                objCartao = Cartao()
                objCartao!!.nomeBanco = binding.edtNomeBanco.text.toString()
                objCartao!!.diaVencimento = binding.edtDiaVencimento.text.toString().toInt()
                objCartao!!.limite = binding.edtLimite.text.toString().toFloat()

                objCartaoDAO = CartaoDAO(this@CadastroCartaoActivity)

                objCartaoDAO.cadastrarCartao(objCartao!!)

                limparCampos()
            }else{
                objCartao!!.nomeBanco = binding.edtNomeBanco.text.toString()
                objCartao!!.diaVencimento = binding.edtDiaVencimento.text.toString().toInt()
                objCartao!!.limite = binding.edtLimite.text.toString().toFloat()

                objCartaoDAO = CartaoDAO(this@CadastroCartaoActivity)
                objCartaoDAO.alterarCartao(objCartao!!)
                limparCampos()
                startActivity(Intent(this@CadastroCartaoActivity,ListarCartaoActivity::class.java))
            }
        }
    }

    fun limparCampos(){
        binding.edtNomeBanco.setText("")
        binding.edtDiaVencimento.setText("")
        binding.edtLimite.setText("")
        binding.edtNomeBanco.requestFocus()
    }
}


