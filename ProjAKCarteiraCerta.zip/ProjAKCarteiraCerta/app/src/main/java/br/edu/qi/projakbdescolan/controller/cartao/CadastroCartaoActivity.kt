package br.edu.qi.projakbdescolan.controller.cartao

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import br.edu.qi.projakbdescolan.databinding.ActivityCadastroCartaoBinding

class CadastroCartaoActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCadastroCartaoBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCadastroCartaoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.txtCancelarCadastro.setOnClickListener {
            startActivity(Intent(this@CadastroCartaoActivity, ListarCartaoActivity::class.java))
        }

        binding.btnCadastrar.setOnClickListener {
            startActivity(Intent(this@CadastroCartaoActivity, ListarCartaoActivity::class.java))
        }
    }
}