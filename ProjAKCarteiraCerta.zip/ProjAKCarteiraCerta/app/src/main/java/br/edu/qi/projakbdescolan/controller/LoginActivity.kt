package br.edu.qi.projakbdescolan.controller

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import br.edu.qi.projakbdescolan.controller.cartao.ListarCartaoActivity
import br.edu.qi.projakbdescolan.databinding.ActivityLoginBinding
import br.edu.qi.projakbdescolan.controller.usuario.CadastroActivity
import br.edu.qi.projakbdescolan.controller.usuario.ListarActivity
import br.edu.qi.projakbdescolan.model.dao.UsuarioDAO
import br.edu.qi.projakbdescolan.model.dto.Usuario

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    private lateinit var objUsuarioDAO: UsuarioDAO
    private var lst : List<Usuario> = ArrayList()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)


        binding.btnEntrar.setOnClickListener {
            objUsuarioDAO = UsuarioDAO(this@LoginActivity)

            lst = objUsuarioDAO.listarTodosOsUsuarios()
            var naoEncontrado : Boolean = true

            for (i in lst.indices){
                if(lst[i].usuario.equals(binding.edtUserLogin.text.toString()) && lst[i].senha.equals(binding.edtPwdLogin.text.toString())){
                    startActivity(Intent(this@LoginActivity,ListarCartaoActivity::class.java))
                    naoEncontrado = false
                }
            }
            if(naoEncontrado){
                Toast.makeText(this@LoginActivity, "Usuário ou senha incorretos", Toast.LENGTH_SHORT).show()
                binding.edtUserLogin.setError("")
                binding.edtPwdLogin.setError("")
            }

        }

        binding.txtCadastrese.setOnClickListener {
            val i = Intent(this@LoginActivity, CadastroActivity::class.java)
            i.putExtra("novo_usuario",true)
            startActivity(i)
        }


    }

}