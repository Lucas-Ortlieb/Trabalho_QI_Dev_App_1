package br.edu.qi.projakbdescolan.model.dao

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import br.edu.qi.projakbdescolan.model.conexao.ConexaoBD
import br.edu.qi.projakbdescolan.model.dto.Usuario

class UsuarioDAO(contexto:Context) {
    private val conexaoBD : ConexaoBD = ConexaoBD(contexto)
    private val bdCartao : SQLiteDatabase = conexaoBD.writableDatabase


    fun cadastrarUsuario(objUsuario : Usuario){
        val valoresCampos = ContentValues()
        valoresCampos.put("nome",objUsuario.nome)
        valoresCampos.put("cpf",objUsuario.cpf)
        valoresCampos.put("telefone",objUsuario.telefone)
        valoresCampos.put("usuario",objUsuario.usuario)
        valoresCampos.put("senha",objUsuario.senha)

        bdCartao.insert("tb_usuario",null,valoresCampos)
    }



    fun listarTodosOsUsuarios() : List<Usuario>{
        val todosOsUsuario : MutableList<Usuario> = ArrayList()

        val campos = arrayOf("pkidusuario","nome","cpf","telefone","usuario","senha")
        val cursor = bdCartao.query("tb_usuario",campos,null,null,null,null,null)

        while (cursor.moveToNext()){
            val objUsuario : Usuario = Usuario()
            objUsuario.id = cursor.getInt(0)
            objUsuario.nome = cursor.getString(1)
            objUsuario.cpf = cursor.getLong(2)
            objUsuario.telefone = cursor.getString(3)
            objUsuario.usuario = cursor.getString(4)
            objUsuario.senha = cursor.getString(5)

            todosOsUsuario.add(objUsuario)
        }

        return todosOsUsuario
    }


    fun alterarUsuario(usuarioAAlterar : Usuario){
        val valoresCampos = ContentValues()
        valoresCampos.put("nome",usuarioAAlterar.nome)
        valoresCampos.put("cpf",usuarioAAlterar.cpf)
        valoresCampos.put("telefone",usuarioAAlterar.telefone)
        valoresCampos.put("usuario",usuarioAAlterar.usuario)
        valoresCampos.put("senha",usuarioAAlterar.senha)

        val id = arrayOf(usuarioAAlterar.id.toString())

        bdCartao.update("tb_usuario",valoresCampos,"pkidusuario = ?",id)
    }

    fun excluirUsuario(usuarioAExcluir : Usuario){
        val id = arrayOf(usuarioAExcluir.id.toString())
        bdCartao.delete("tb_usuario","pkidusuario = ?",id)
    }
}