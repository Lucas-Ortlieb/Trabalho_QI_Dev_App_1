package br.edu.qi.projakbdescolan.controller

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import br.edu.qi.projakbdescolan.controller.usuario.CadastroActivity
import br.edu.qi.projakbdescolan.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnLogar.setOnClickListener {
            val i = Intent(this@MainActivity, LoginActivity::class.java)
            startActivity(i)
        }

        binding.txtCadastreSe.setOnClickListener {
            startActivity(Intent(this@MainActivity, CadastroActivity::class.java))
        }
    }
}