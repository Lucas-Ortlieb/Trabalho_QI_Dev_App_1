package br.edu.qi.projakbdescolan.controller.usuario

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.*
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.SearchView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import br.edu.qi.projakbdescolan.R
import br.edu.qi.projakbdescolan.controller.MainActivity
import br.edu.qi.projakbdescolan.controller.cartao.ListarCartaoActivity
import br.edu.qi.projakbdescolan.databinding.ActivityListarBinding
import br.edu.qi.projakbdescolan.model.dao.UsuarioDAO
import br.edu.qi.projakbdescolan.model.dto.Usuario
import java.util.*
import kotlin.collections.ArrayList

class ListarActivity : AppCompatActivity() {
    private lateinit var binding: ActivityListarBinding
    private lateinit var objUsuarioDAO: UsuarioDAO
    private lateinit var mi : MenuInflater
    private lateinit var cadastrar : MenuItem
    private lateinit var sair : MenuItem
    private lateinit var pesquisar : SearchView
    private lateinit var alterar : MenuItem
    private lateinit var excluir : MenuItem
    private var todosOsUsuarios : MutableList<Usuario> = ArrayList()
    private var usuariosEncontrados : MutableList<Usuario> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityListarBinding.inflate(layoutInflater)
        setContentView(binding.root)
        objUsuarioDAO = UsuarioDAO(this@ListarActivity)

        todosOsUsuarios = objUsuarioDAO.listarTodosOsUsuarios().toMutableList()

        usuariosEncontrados.addAll(todosOsUsuarios)

        binding.lstAlunos.adapter = ArrayAdapter(this@ListarActivity,android.R.layout.simple_list_item_1,usuariosEncontrados)

        mi = menuInflater

        registerForContextMenu(binding.lstAlunos)

        binding.txtVoltarListaCartao.setOnClickListener {
            startActivity(Intent(this@ListarActivity, ListarCartaoActivity::class.java))
        }

    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        mi.inflate(R.menu.menu_superior,menu)

        cadastrar = menu!!.findItem(R.id.icCadastrar)
        sair = menu.findItem(R.id.icSair)
        pesquisar = menu.findItem(R.id.icPesquisar).actionView as SearchView

        cadastrar.setOnMenuItemClickListener {
            startActivity(Intent(this@ListarActivity, CadastroActivity::class.java))
            true
        }
        sair.setOnMenuItemClickListener {
            startActivity(Intent(this@ListarActivity, MainActivity::class.java))
            true
        }

        pesquisar.setOnQueryTextListener(object : SearchView.OnQueryTextListener{
            override fun onQueryTextSubmit(p0: String?): Boolean {
                TODO("Not yet implemented")
            }

            override fun onQueryTextChange(nome: String?): Boolean {
                pesquisarAlunoPorNome(nome!!)
                return true
            }

        })
        return true
    }
    override fun onCreateContextMenu(menu: ContextMenu?, v: View?, menuInfo: ContextMenu.ContextMenuInfo?) {
        mi.inflate(R.menu.menu_opcoes,menu)

        excluir = menu!!.findItem(R.id.moExcluir)
        excluir.setOnMenuItemClickListener {menuItem ->
            val usuarioEscolhido = menuItem.menuInfo as AdapterView.AdapterContextMenuInfo
            val usuarioAExcluir : Usuario = usuariosEncontrados[usuarioEscolhido.position]

            val confirmacao = AlertDialog.Builder(this@ListarActivity)
                .setTitle("Atenção!")
                .setMessage("Deseja excluir o usuário ${usuarioAExcluir.nome}?")
                .setNegativeButton("Não",null)
                .setPositiveButton("Sim"){_,_ ->
                    objUsuarioDAO.excluirUsuario(usuarioAExcluir)
                    todosOsUsuarios.remove(usuarioAExcluir)
                    usuariosEncontrados.remove(usuarioAExcluir)
                    binding.lstAlunos.invalidateViews()
                    Toast.makeText(this@ListarActivity, "Usuario excluído com sucesso!", Toast.LENGTH_SHORT).show()
                }.create()
            confirmacao.show()
            true
        }

        alterar = menu.findItem(R.id.moAlterar)
        alterar.setOnMenuItemClickListener {menuItem ->
            val usuarioEscolhido = menuItem.menuInfo as AdapterView.AdapterContextMenuInfo
            val usuarioAAlterar : Usuario = usuariosEncontrados[usuarioEscolhido.position]

            val i = Intent(this@ListarActivity,CadastroActivity::class.java)
            i.putExtra("usuario_alterar",usuarioAAlterar)
            startActivity(i)


            true
        }


        super.onCreateContextMenu(menu, v, menuInfo)
    }

    fun pesquisarAlunoPorNome(nome : String){
        usuariosEncontrados.clear()
        for (i in todosOsUsuarios.indices){
            if(todosOsUsuarios[i].nome!!.lowercase(Locale.getDefault()).contains(nome.lowercase(Locale.getDefault()))){
                usuariosEncontrados.add(todosOsUsuarios[i])
            }
        }
        binding.lstAlunos.invalidateViews()
    }
}