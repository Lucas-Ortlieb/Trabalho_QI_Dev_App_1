package br.edu.qi.projakbdescolan.controller.usuario

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import br.edu.qi.projakbdescolan.controller.LoginActivity
import br.edu.qi.projakbdescolan.controller.MainActivity
import br.edu.qi.projakbdescolan.databinding.ActivityCadastroBinding
import br.edu.qi.projakbdescolan.model.dao.UsuarioDAO
import br.edu.qi.projakbdescolan.model.dto.Usuario

class CadastroActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCadastroBinding
    private var objUsuario: Usuario? = null
    private lateinit var objUsuarioDAO: UsuarioDAO

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCadastroBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val i = intent

        if (i.hasExtra("usuario_alterar")) {
            objUsuario = i.getSerializableExtra("usuario_alterar") as Usuario
            binding.edtNome.setText(objUsuario!!.nome)
            binding.edtCpf.setText(objUsuario!!.cpf.toString())
            binding.edtTelefone.setText(objUsuario!!.telefone)
            binding.edtUsuario.setText(objUsuario!!.usuario)
            binding.edtSenha.setText(objUsuario!!.senha)
            binding.btnCadastrar.text = "Alterar"
            binding.txtCadastreSe.setText("Altere os dados")

        }



        binding.txtSair.setOnClickListener {
            startActivity(Intent(this@CadastroActivity, MainActivity::class.java))
        }


        binding.btnCadastrar.setOnClickListener {
            if (objUsuario == null) {

                objUsuario = Usuario()

                objUsuario!!.nome = binding.edtNome.text.toString()
                objUsuario!!.cpf = binding.edtCpf.text.toString().toLong()
                objUsuario!!.telefone = binding.edtTelefone.text.toString()
                objUsuario!!.usuario = binding.edtUsuario.text.toString()
                objUsuario!!.senha = binding.edtSenha.text.toString()

                objUsuarioDAO = UsuarioDAO(this@CadastroActivity)

                objUsuarioDAO.cadastrarUsuario(objUsuario!!)

                limparCampos()
            } else {
                objUsuario!!.nome = binding.edtNome.text.toString()
                objUsuario!!.cpf = binding.edtCpf.text.toString().toLong()
                objUsuario!!.telefone = binding.edtTelefone.text.toString()
                objUsuario!!.usuario = binding.edtUsuario.text.toString()
                objUsuario!!.senha = binding.edtSenha.text.toString()

                objUsuarioDAO = UsuarioDAO(this@CadastroActivity)
                objUsuarioDAO.alterarUsuario(objUsuario!!)
                limparCampos()
                startActivity(Intent(this@CadastroActivity, ListarActivity::class.java))

            }
        }
    }

    fun limparCampos() {
        binding.edtNome.setText("")
        binding.edtCpf.setText("")
        binding.edtTelefone.setText("")
        binding.edtUsuario.setText("")
        binding.edtSenha.setText("")
        binding.edtNome.requestFocus()
    }
}