package br.edu.qi.projakbdescolan.controller.usuario

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import br.edu.qi.projakbdescolan.controller.LoginActivity
import br.edu.qi.projakbdescolan.controller.MainActivity
import br.edu.qi.projakbdescolan.databinding.ActivityCadastroBinding
import br.edu.qi.projakbdescolan.model.dao.UsuarioDAO
import br.edu.qi.projakbdescolan.model.dto.Usuario

class CadastroActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCadastroBinding
    private lateinit var objUsuario: Usuario
    private lateinit var objUsuarioDAO: UsuarioDAO

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCadastroBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.txtListar.setOnClickListener {
            startActivity(Intent(this@CadastroActivity, ListarActivity::class.java))
        }

        binding.txtSair.setOnClickListener {
            startActivity(Intent(this@CadastroActivity, MainActivity::class.java))
        }


        binding.btnCadastrar.setOnClickListener {
            objUsuario = Usuario()

            objUsuario.nome = binding.edtNome.text.toString()
            objUsuario.cpf = binding.edtCpf.text.toString().toLong()
            objUsuario.telefone = binding.edtTelefone.text.toString()
            objUsuario.usuario = binding.edtUsuario.text.toString()
            objUsuario.senha = binding.edtSenha.text.toString()

            objUsuarioDAO = UsuarioDAO(this@CadastroActivity)

            objUsuarioDAO.cadastrarUsuario(objUsuario)
            startActivity(Intent(this@CadastroActivity, LoginActivity::class.java))
        }

    }
}