package br.edu.qi.projakbdescolan.model.dao

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import br.edu.qi.projakbdescolan.model.conexao.ConexaoBD
import br.edu.qi.projakbdescolan.model.dto.Cartao
import br.edu.qi.projakbdescolan.model.dto.Usuario

class CartaoDAO(contexto: Context) {
    private val conexaoBD : ConexaoBD = ConexaoBD(contexto)
    private val bdCartao : SQLiteDatabase = conexaoBD.writableDatabase


    fun cadastrarCartao(objCartao: Cartao){
        val valoresCampos = ContentValues()
        valoresCampos.put("nomeBanco",objCartao.nomeBanco)
        valoresCampos.put("diaVencimento",objCartao.diaVencimento)
        valoresCampos.put("limite",objCartao.limite)

        bdCartao.insert("tb_cartao",null,valoresCampos)
    }



    fun listarTodosOsCartoes() : List<Cartao>{
        val todosOsCartao : MutableList<Cartao> = ArrayList()

        val campos = arrayOf("pkidcartao","nomeBanco","diaVencimento","limite")
        val cursor = bdCartao.query("tb_cartao",campos,null,null,null,null,null)

        while (cursor.moveToNext()){
            val objCartao : Cartao = Cartao()
            objCartao.id = cursor.getInt(0)
            objCartao.nomeBanco = cursor.getString(1)
            objCartao.diaVencimento = cursor.getInt(2)
            objCartao.limite = cursor.getFloat(3)


            todosOsCartao.add(objCartao)
        }

        return todosOsCartao
    }





    fun alterarAluno(){

    }

    fun excluirAluno(){

    }
}