package br.edu.qi.projakbdescolan.model.dto

class Cartao {
    var id : Int = 0
    var nomeBanco : String? = null
    var diaVencimento : Int = 0
    var limite : Float = 0f

    override fun toString(): String {
        return """
             :::::::::::::::::::::::::::::::::::::::::::::::::
               ID: $id 
               Banco: $nomeBanco
               Dia do Vencimento: $diaVencimento
               Limite: $limite
             :::::::::::::::::::::::::::::::::::::::::::::::::
            """.trimIndent()
    }
}