package br.edu.qi.projakbdescolan.controller.cartao

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.*
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.SearchView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import br.edu.qi.projakbdescolan.R
import br.edu.qi.projakbdescolan.controller.MainActivity
import br.edu.qi.projakbdescolan.controller.usuario.ListarActivity
import br.edu.qi.projakbdescolan.databinding.ActivityListarCartaoBinding
import br.edu.qi.projakbdescolan.model.dao.CartaoDAO
import br.edu.qi.projakbdescolan.model.dto.Cartao
import java.util.Locale
import kotlin.collections.ArrayList

class ListarCartaoActivity : AppCompatActivity() {
    private lateinit var binding: ActivityListarCartaoBinding
    private lateinit var objCartaoDAO: CartaoDAO
    private lateinit var mi : MenuInflater
    private lateinit var cadastrar : MenuItem
    private lateinit var sair : MenuItem
    private lateinit var pesquisar : SearchView
    private lateinit var alterar : MenuItem
    private lateinit var excluir : MenuItem
    private var todosOsCartoes : MutableList<Cartao> = ArrayList()
    private var cartoesEncontrados : MutableList<Cartao> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityListarCartaoBinding.inflate(layoutInflater)
        setContentView(binding.root)
        objCartaoDAO = CartaoDAO(this@ListarCartaoActivity)

        todosOsCartoes = objCartaoDAO.listarTodosOsCartoes().toMutableList()

        cartoesEncontrados.addAll(todosOsCartoes)

        binding.lstCartoes.adapter = ArrayAdapter(this@ListarCartaoActivity, android.R.layout.simple_list_item_1,cartoesEncontrados)

        mi = menuInflater

        registerForContextMenu(binding.lstCartoes)

        binding.btnAdicionaCartao.setOnClickListener {
            startActivity(Intent(this@ListarCartaoActivity, CadastroCartaoActivity::class.java))
        }

        binding.txtListar.setOnClickListener {
            startActivity(Intent(this@ListarCartaoActivity,ListarActivity::class.java))
        }


    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        mi.inflate(br.edu.qi.projakbdescolan.R.menu.menu_superior,menu)

        cadastrar = menu!!.findItem(br.edu.qi.projakbdescolan.R.id.icCadastrar)
        sair = menu.findItem(br.edu.qi.projakbdescolan.R.id.icSair)
        pesquisar = menu.findItem(br.edu.qi.projakbdescolan.R.id.icPesquisar).actionView as SearchView

        cadastrar.setOnMenuItemClickListener {
            startActivity(Intent(this@ListarCartaoActivity, CadastroCartaoActivity::class.java))
            true
        }
        sair.setOnMenuItemClickListener {
            startActivity(Intent(this@ListarCartaoActivity, MainActivity::class.java))
            true
        }

        pesquisar.setOnQueryTextListener(object : SearchView.OnQueryTextListener{
            override fun onQueryTextSubmit(p0: String?): Boolean {
                TODO("Not yet implemented")
            }

            override fun onQueryTextChange(nome: String?): Boolean {
                pesquisarCartaoPorNome(nome!!)
                return true
            }

        })
        return true
    }


    override fun onCreateContextMenu(menu: ContextMenu?, v: View?, menuInfo: ContextMenu.ContextMenuInfo?) {
        mi.inflate(R.menu.menu_opcoes,menu)

        excluir = menu!!.findItem(R.id.moExcluir)
        excluir.setOnMenuItemClickListener {menuItem ->
            val cartaoEscolhido = menuItem.menuInfo as AdapterView.AdapterContextMenuInfo
            val cartaoAExcluir : Cartao = cartoesEncontrados[cartaoEscolhido.position]

            val confirmacao = AlertDialog.Builder(this@ListarCartaoActivity)
                .setTitle("Atenção!")
                .setMessage("Deseja excluir o cartao ${cartaoAExcluir.nomeBanco}?")
                .setNegativeButton("Não",null)
                .setPositiveButton("Sim"){_,_ ->
                    objCartaoDAO.excluirCartao(cartaoAExcluir)
                    todosOsCartoes.remove(cartaoAExcluir)
                    cartoesEncontrados.remove(cartaoAExcluir)
                    binding.lstCartoes.invalidateViews()
                    Toast.makeText(this@ListarCartaoActivity, "Cartão excluído com sucesso!", Toast.LENGTH_SHORT).show()
                }.create()
            confirmacao.show()
            true
        }

        alterar = menu.findItem(R.id.moAlterar)
        alterar.setOnMenuItemClickListener {menuItem ->
            val cartaoEscolhido = menuItem.menuInfo as AdapterView.AdapterContextMenuInfo
            val cartaoAAlterar : Cartao = cartoesEncontrados[cartaoEscolhido.position]

            val i = Intent(this@ListarCartaoActivity,CadastroCartaoActivity::class.java)
            i.putExtra("cartao_alterar",cartaoAAlterar)
            startActivity(i)


            true
        }


        super.onCreateContextMenu(menu, v, menuInfo)
    }


    fun pesquisarCartaoPorNome(nome : String){
        cartoesEncontrados.clear()
        for (i in todosOsCartoes.indices){
            if(todosOsCartoes[i].nomeBanco!!.lowercase(Locale.getDefault()).contains(nome.lowercase(
                    Locale.getDefault()))){
                cartoesEncontrados.add(todosOsCartoes[i])
            }
        }
        binding.lstCartoes.invalidateViews()
    }
}
