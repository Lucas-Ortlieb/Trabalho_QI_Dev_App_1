package br.edu.qi.projakbdescolan.controller.cartao

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.widget.ArrayAdapter
import android.widget.SearchView
import br.edu.qi.projakbdescolan.controller.MainActivity
import br.edu.qi.projakbdescolan.databinding.ActivityListarCartaoBinding
import br.edu.qi.projakbdescolan.model.dao.CartaoDAO
import br.edu.qi.projakbdescolan.model.dto.Cartao
import java.util.Locale
import kotlin.collections.ArrayList

class ListarCartaoActivity : AppCompatActivity() {
    private lateinit var binding: ActivityListarCartaoBinding
    private lateinit var objCartaoDAO: CartaoDAO
    private lateinit var mi : MenuInflater
    private lateinit var cadastrar : MenuItem
    private lateinit var sair : MenuItem
    private lateinit var pesquisar : SearchView
    private var todosOsCartoes : List<Cartao> = ArrayList()
    private var cartoesEncontrados : MutableList<Cartao> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityListarCartaoBinding.inflate(layoutInflater)
        setContentView(binding.root)
        objCartaoDAO = CartaoDAO(this@ListarCartaoActivity)

        todosOsCartoes = objCartaoDAO.listarTodosOsCartoes()

        cartoesEncontrados.addAll(todosOsCartoes)

        binding.lstCartoes.adapter = ArrayAdapter(this@ListarCartaoActivity, android.R.layout.simple_list_item_1,cartoesEncontrados)

        mi = menuInflater

        binding.btnAdicionaCartao.setOnClickListener {
            startActivity(Intent(this@ListarCartaoActivity, CadastroCartaoActivity::class.java))
        }


    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        mi.inflate(br.edu.qi.projakbdescolan.R.menu.menu_superior,menu)

        cadastrar = menu!!.findItem(br.edu.qi.projakbdescolan.R.id.icCadastrar)
        sair = menu.findItem(br.edu.qi.projakbdescolan.R.id.icSair)
        pesquisar = menu.findItem(br.edu.qi.projakbdescolan.R.id.icPesquisar).actionView as SearchView

        cadastrar.setOnMenuItemClickListener {
            startActivity(Intent(this@ListarCartaoActivity, CadastroCartaoActivity::class.java))
            true
        }
        sair.setOnMenuItemClickListener {
            startActivity(Intent(this@ListarCartaoActivity, MainActivity::class.java))
            true
        }

        pesquisar.setOnQueryTextListener(object : SearchView.OnQueryTextListener{
            override fun onQueryTextSubmit(p0: String?): Boolean {
                TODO("Not yet implemented")
            }

            override fun onQueryTextChange(nome: String?): Boolean {
                pesquisarCartaoPorNome(nome!!)
                return true
            }

        })
        return true
    }

    fun pesquisarCartaoPorNome(nome : String){
        cartoesEncontrados.clear()
        for (i in todosOsCartoes.indices){
            if(todosOsCartoes[i].nomeBanco!!.lowercase(Locale.getDefault()).contains(nome.lowercase(
                    Locale.getDefault()))){
                cartoesEncontrados.add(todosOsCartoes[i])
            }
        }
        binding.lstCartoes.invalidateViews()
    }
}
