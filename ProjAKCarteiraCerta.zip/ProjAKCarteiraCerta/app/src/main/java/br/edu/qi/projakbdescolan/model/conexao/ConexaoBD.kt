package br.edu.qi.projakbdescolan.model.conexao

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class ConexaoBD(contexto : Context) : SQLiteOpenHelper(contexto,NAME,null,VERSION) {

    companion object{
        private val NAME : String = "bdUsuario"
        private val VERSION : Int = 1
    }

    override fun onCreate(bdUsuario : SQLiteDatabase) {
        bdUsuario.execSQL(
            "create table tb_usuario(" +
                    "pkidusuario integer not null primary key autoincrement," +
                    "nome varchar(100) not null," +
                    "cpf bigint not null unique," +
                    "telefone varchar(50) not null," +
                    "usuario varchar(45) not null unique," +
                    "senha varchar(16) not null)"
        )
    }
    override fun onUpgrade(p0: SQLiteDatabase?, p1: Int, p2: Int) {

    }
}